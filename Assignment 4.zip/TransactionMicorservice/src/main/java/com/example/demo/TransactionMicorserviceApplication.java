package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionMicorserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionMicorserviceApplication.class, args);
	}

}
